import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';
import jsonServer from 'json-server';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
const angularApp = new AngularNodeAppEngine();

/**
 * MOCK API: JSON-Server mounted on /api
 * This guarantees it runs seamlessly within the Angular SSR Express container.
 */
const mockApiRouter = jsonServer.router('db.json');
const mockApiMiddlewares = jsonServer.defaults();

/**
 * Google OAuth Endpoints
 */
app.get('/api/auth/google/url', (req, res) => {
  const redirectUri = `${process.env['APP_URL'] || `http://${req.headers.host}`}/api/auth/google/callback`;
  const params = new URLSearchParams({
    client_id: process.env['GOOGLE_CLIENT_ID'] || '',
    redirect_uri: redirectUri,
    response_type: 'code',
    scope: 'openid email profile',
  });
  res.json({ url: `https://accounts.google.com/o/oauth2/v2/auth?${params}` });
});

app.get(['/api/auth/google/callback', '/api/auth/google/callback/'], async (req, res) => {
  try {
    const code = req.query['code'] as string;
    const redirectUri = `${process.env['APP_URL'] || `http://${req.headers.host}`}/api/auth/google/callback`;
    
    if (!code) throw new Error('No code provided');

    // Exchange code for token
    const tokenResponse = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        code,
        client_id: process.env['GOOGLE_CLIENT_ID'] || '',
        client_secret: process.env['GOOGLE_CLIENT_SECRET'] || '',
        redirect_uri: redirectUri,
        grant_type: 'authorization_code',
      }),
    });

    const tokenData = await tokenResponse.json();
    if (!tokenResponse.ok) throw new Error(tokenData.error_description || 'Token info failed');

    // Fetch user info
    const userResponse = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
      headers: { Authorization: `Bearer ${tokenData.access_token}` },
    });
    const userData = await userResponse.json();

    res.send(`
      <html><body>
        <script>
          if (window.opener) {
            window.opener.postMessage({ type: 'OAUTH_AUTH_SUCCESS', payload: ${JSON.stringify(userData)} }, '*');
            window.close();
          } else {
            window.location.href = '/login';
          }
        </script>
        <p>Autenticação bem-sucedida. Esta janela será fechada automaticamente.</p>
      </body></html>
    `);
  } catch (error: unknown) {
    console.error('OAuth Callback Error:', error);
    const msg = error instanceof Error ? error.message : 'Unknown error';
    res.send(`<html><body><p>Erro na autenticação: ${msg}</p></body></html>`);
  }
});

app.use('/api', mockApiMiddlewares, mockApiRouter);

/**
 * Example Express Rest API endpoints can be defined here.
 * Uncomment and define endpoints as necessary.
 *
 * Example:
 * ```ts
 * app.get('/api/{*splat}', (req, res) => {
 *   // Handle API request
 * });
 * ```
 */

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 4000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);
