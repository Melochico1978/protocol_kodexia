import {Routes} from '@angular/router';
import {authGuard} from './guards/auth.guard';

export const routes: Routes = [
  { path: '', loadComponent: () => import('./pages/splash/splash').then(m => m.SplashComponent) },
  { path: 'login', loadComponent: () => import('./pages/login/login').then(m => m.LoginComponent) },
  { path: 'register', loadComponent: () => import('./pages/login/register').then(m => m.RegisterComponent) },
  { path: 'home', loadComponent: () => import('./pages/home/home').then(m => m.HomeComponent), canActivate: [authGuard] },
  { path: 'story/intro', loadComponent: () => import('./pages/story/intro/intro').then(m => m.StoryIntroComponent), canActivate: [authGuard] },
  { path: 'story/map', loadComponent: () => import('./pages/story/story-map').then(m => m.StoryMapComponent), canActivate: [authGuard] },
  { path: 'story/level/:id', loadComponent: () => import('./pages/story/level/level').then(m => m.LevelComponent), canActivate: [authGuard] },
  { path: '**', redirectTo: '' }
];

