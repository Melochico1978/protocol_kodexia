import { Injectable } from '@angular/core';
import Dexie, { Table } from 'dexie';

export interface UserProfile {
  id: number;
  name: string;
  email: string;
  token?: string;
  xp: number;
  level: number;
  fullName?: string;
  nickname?: string;
  password?: string;
  isGoogleAuth?: boolean;
  avatarUrl?: string;
}

export interface Card {
  id: number;
  name: string;
  language: string;
  power: number;
  type: string;
  owned: boolean;
}

export interface LevelProgress {
  id: number;
  completed: boolean;
  score: number;
}

@Injectable({
  providedIn: 'root'
})
export class DbService extends Dexie {
  users!: Table<UserProfile, number>;
  cards!: Table<Card, number>;
  progress!: Table<LevelProgress, number>;

  constructor() {
    super('KodexiaDB');
    this.version(1).stores({
      users: '++id, email',
      cards: '++id, name, language',
      progress: '++id'
    });
  }

  async initDefaultData() {
    const userCount = await this.users.count();
    if (userCount === 0) {
      await this.users.add({
        id: 1,
        name: 'Zero N',
        email: 'zero.n@kodexia.gov',
        xp: 0,
        level: 1
      });
      
      const defaultCards = [
        { id: 1, name: 'Java Sênior', language: 'Java', power: 85, type: 'Backend', owned: false },
        { id: 2, name: 'Python Script', language: 'Python', power: 70, type: 'Data', owned: false }
      ];
      await this.cards.bulkAdd(defaultCards);
    }
  }
}
