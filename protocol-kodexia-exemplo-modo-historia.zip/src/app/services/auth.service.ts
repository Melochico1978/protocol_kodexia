import { Injectable, inject, signal } from '@angular/core';
import { DbService, UserProfile } from './db.service';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private db = inject(DbService);
  private router = inject(Router);

  currentUser = signal<UserProfile | null>(null);

  async initAuth() {
    await this.db.initDefaultData();
    const user = await this.db.users.get(1);
    if (user && user.token) {
      this.currentUser.set(user);
    }
  }

  async login(email: string, password?: string, token = 'mock_jwt_token_123') {
    const user = await this.db.users.where('email').equals(email).first();
    if (user) {
      if (password && user.password && user.password !== password) {
        return false;
      }
      user.token = token;
      await this.db.users.put(user);
      this.currentUser.set(user);
      return true;
    }
    
    if (password) {
      return false; // Do not auto-create if a password is provided (traditional login)
    }
    
    // Auto-create for demo purposes
    const newUser: UserProfile = {
      id: Date.now(),
      name: email.split('@')[0],
      email: email,
      token: token,
      xp: 0,
      level: 1
    };
    await this.db.users.add(newUser);
    this.currentUser.set(newUser);
    return true;
  }

  async register(fullName: string, nickname: string, email: string, password: string, token = 'mock_jwt_token_123') {
    const existingUser = await this.db.users.where('email').equals(email).first();
    if (existingUser) {
      return false;
    }

    const newUser: UserProfile = {
      id: Date.now(),
      name: nickname,
      email: email,
      fullName: fullName,
      nickname: nickname,
      password: password,
      token: token,
      xp: 0,
      level: 1
    };
    
    await this.db.users.add(newUser);
    this.currentUser.set(newUser);
    return true;
  }

  async checkUserExists(email: string): Promise<boolean> {
    const user = await this.db.users.where('email').equals(email).first();
    return !!user;
  }

  async loginGoogle(email: string, avatarUrl: string, token = 'mock_google_token_123') {
    const user = await this.db.users.where('email').equals(email).first();
    if (user) {
      user.token = token;
      user.isGoogleAuth = true;
      if (avatarUrl) user.avatarUrl = avatarUrl;
      await this.db.users.put(user);
      this.currentUser.set(user);
      return true;
    }
    return false;
  }

  async registerGoogle(fullName: string, nickname: string, email: string, avatarUrl: string, token = 'mock_google_token_123') {
    const existingUser = await this.db.users.where('email').equals(email).first();
    if (existingUser) return false;

    const newUser: UserProfile = {
      id: Date.now(),
      name: nickname,
      email: email,
      fullName: fullName,
      nickname: nickname,
      token: token,
      isGoogleAuth: true,
      avatarUrl: avatarUrl,
      xp: 0,
      level: 1
    };
    
    await this.db.users.add(newUser);
    this.currentUser.set(newUser);
    return true;
  }

  async logout() {
    const user = this.currentUser();
    if (user) {
      user.token = undefined;
      await this.db.users.put(user);
      this.currentUser.set(null);
      this.router.navigate(['/login']);
    }
  }

  isAuthenticated(): boolean {
    return !!this.currentUser();
  }
}
