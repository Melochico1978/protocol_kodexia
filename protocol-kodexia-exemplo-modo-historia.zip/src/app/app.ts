import {ChangeDetectionStrategy, Component, inject} from '@angular/core';
import {RouterOutlet} from '@angular/router';
import {LoadingService} from './services/loading.service';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [RouterOutlet],
  template: `
    <router-outlet></router-outlet>
    
    @if (loadingService.isLoading()) {
      <div class="fixed inset-0 bg-cyber-dark/80 backdrop-blur-sm z-50 flex flex-col items-center justify-center">
        <div class="h-4 w-48 border border-cyber-pink p-0.5">
           <div class="h-full bg-cyber-pink shadow-[0_0_8px_var(--color-cyber-pink)] animate-pulse w-full"></div>
        </div>
        <span class="font-console text-cyber-pink mt-4 text-xl">Processando Requisição...</span>
      </div>
    }
  `
})
export class App {
  protected loadingService = inject(LoadingService);
}
