import { Component, inject } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  standalone: true,
  selector: 'app-story-map',
  template: `
    <div class="h-full w-full flex flex-col">
      <header class="h-[60px] shrink-0 border-b-2 border-cyber-cyan flex justify-between items-center px-6 bg-[rgba(0,243,255,0.05)] shadow-[0_0_15px_rgba(0,243,255,0.2)]">
        <div class="flex items-center gap-4">
          <button (click)="router.navigate(['/home'])" class="text-cyber-cyan hover:text-white font-console border border-cyber-cyan px-2 py-1 uppercase text-sm">
            < Voltar
          </button>
          <h1 class="font-console font-black text-xl tracking-[2px] text-cyber-cyan uppercase">Mapa do Sistema</h1>
        </div>
        
        <div class="font-console text-sm text-cyber-green uppercase">
          [ Setor: 1.0 - Lógica Básica ]
        </div>
      </header>

      <main class="flex-1 p-6 relative overflow-y-auto bg-black/40">
        <!-- Connecting lines visualization -->
        <div class="absolute w-[2px] bg-cyber-dim/30 left-[50%] top-10 bottom-10 z-0"></div>

        <div class="flex flex-col gap-12 max-w-2xl mx-auto z-10 relative py-8">
          
          <!-- Tutorial Level -->
          <div tabindex="0" (keyup.enter)="goToLevel(1)" class="flex items-center gap-6 group cursor-pointer" (click)="goToLevel(1)">
            <div class="flex-1 text-right">
              <h3 class="font-console text-lg text-cyber-cyan group-hover:text-white transition-colors">Inicialização</h3>
              <p class="font-sans text-xs text-white/50">Fundamentos da Sintaxe</p>
            </div>
            
            <div class="w-16 h-16 rounded-full border-4 border-cyber-cyan bg-cyber-card flex items-center justify-center shadow-[0_0_15px_rgba(0,243,255,0.4)] group-hover:scale-110 transition-transform">
              <span class="font-console text-xl font-bold text-cyber-cyan">01</span>
            </div>
            
            <div class="flex-1 font-console text-cyber-green text-sm">
              [ 100% CONCLUÍDO ]
            </div>
          </div>

          <!-- Variable Level -->
          <div tabindex="0" (keyup.enter)="goToLevel(2)" class="flex items-center gap-6 group cursor-pointer" (click)="goToLevel(2)">
             <div class="flex-1 text-right font-console text-cyber-yellow text-sm">
              [ EM PROGRESSO ]
            </div>

            <div class="w-16 h-16 rounded-full border-4 border-cyber-yellow bg-cyber-card flex items-center justify-center shadow-[0_0_15px_rgba(252,238,10,0.4)] group-hover:scale-110 transition-transform relative">
              <div class="absolute inset-0 border-2 border-cyber-yellow rounded-full animate-ping opacity-20"></div>
              <span class="font-console text-xl font-bold text-cyber-yellow">02</span>
            </div>

            <div class="flex-1 text-left">
              <h3 class="font-console text-lg text-cyber-yellow group-hover:text-white transition-colors">Alocação de Memória</h3>
              <p class="font-sans text-xs text-white/50">Variáveis e Tipos</p>
            </div>
          </div>

          <!-- Control Flow Level (Locked) -->
          <div class="flex items-center gap-6 group opacity-50 cursor-not-allowed">
            <div class="flex-1 text-right">
              <h3 class="font-console text-lg text-white">Fluxo de Controle</h3>
              <p class="font-sans text-xs text-white/50">Condicionais if/else</p>
            </div>
            
            <div class="w-16 h-16 rounded-full border-4 border-cyber-dim bg-cyber-card flex items-center justify-center">
              <span class="material-icons text-cyber-dim">lock</span>
            </div>
            
            <div class="flex-1 font-console text-cyber-dim text-sm">
              [ BLOQUEADO ]
            </div>
          </div>

        </div>
      </main>

    </div>
  `
})
export class StoryMapComponent {
  router = inject(Router);

  goToLevel(id: number) {
    this.router.navigate(['/story/level', id]);
  }
}
