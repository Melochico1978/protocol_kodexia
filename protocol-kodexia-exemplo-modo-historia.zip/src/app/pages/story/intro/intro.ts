import { Component, HostListener, inject, OnInit, OnDestroy, signal } from '@angular/core';
import { Router } from '@angular/router';

interface IntroSlide {
  id: number;
  speaker: string;
  text: string;
  imageType: 'miraberto' | 'ralapenha' | 'zero_n' | 'miraberto_final';
}

@Component({
  standalone: true,
  selector: 'app-story-intro',
  template: `
    <div 
      class="h-screen w-full bg-cyber-dark text-cyber-cyan flex flex-col items-center justify-center p-6 relative overflow-hidden focus:outline-none"
      (click)="advance()"
      (keydown.enter)="advance()"
      tabindex="0"
    >
      <!-- Terminal scanline effect -->
      <div class="z-0 absolute inset-0 opacity-20 pointer-events-none" 
           style="background-image: repeating-linear-gradient(0deg, transparent, transparent 2px, #00f3ff 2px, #00f3ff 4px); background-size: 100% 4px;">
      </div>

      <div class="z-10 w-full max-w-4xl flex flex-col items-center gap-10">
        
        <!-- Avatar Display -->
        <div class="h-56 w-56 border-4 bg-cyber-card flex items-center justify-center relative shadow-[0_0_30px_rgba(0,0,0,0.8)] transition-all duration-500"
             [class.border-cyber-green]="currentSlideData().imageType === 'miraberto' || currentSlideData().imageType === 'miraberto_final'"
             [class.border-cyber-pink]="currentSlideData().imageType === 'ralapenha'"
             [class.border-cyber-cyan]="currentSlideData().imageType === 'zero_n'"
             [class.shadow-[0_0_40px_rgba(57,255,20,0.5)]]="currentSlideData().imageType === 'miraberto' || currentSlideData().imageType === 'miraberto_final'"
             [class.shadow-[0_0_40px_rgba(255,0,255,0.5)]]="currentSlideData().imageType === 'ralapenha'"
             [class.shadow-[0_0_40px_rgba(0,243,255,0.5)]]="currentSlideData().imageType === 'zero_n'">
             
           @if (currentSlideData().imageType === 'miraberto' || currentSlideData().imageType === 'miraberto_final') {
             <div class="flex flex-col items-center gap-2">
               <span class="material-icons text-cyber-green" style="font-size: 80px;">school</span>
               <span class="font-console text-cyber-green text-[10px] font-bold uppercase tracking-widest text-center mt-2">Prof. Miraberto</span>
             </div>
           }
           @if (currentSlideData().imageType === 'ralapenha') {
             <div class="flex flex-col items-center gap-2">
               <span class="material-icons text-cyber-pink" style="font-size: 80px;">bug_report</span>
               <span class="font-console text-cyber-pink text-[10px] font-bold uppercase tracking-widest text-center mt-2">Hacker<br>Ralapenha</span>
             </div>
           }
           @if (currentSlideData().imageType === 'zero_n') {
             <div class="flex flex-col items-center gap-2">
               <span class="material-icons text-cyber-cyan" style="font-size: 80px;">terminal</span>
               <span class="font-console text-cyber-cyan text-[10px] font-bold uppercase tracking-widest text-center mt-2">Agente<br>Zero N</span>
             </div>
           }
        </div>

        <!-- Terminal Text Box -->
        <div class="w-full border-2 border-cyber-cyan bg-[#050508]/90 p-8 min-h-[220px] relative shadow-[0_0_20px_rgba(0,243,255,0.15)] backdrop-blur-sm cursor-pointer">
          <div class="font-console text-sm text-cyber-dim mb-6 border-b border-cyber-dim/30 pb-2 uppercase tracking-wider flex justify-between">
            <span>> CONN_SECURE :: {{ currentSlideData().speaker }}</span>
            <span class="text-cyber-green animate-pulse">● REC</span>
          </div>
          <div class="font-console text-xl leading-relaxed text-white">
            {{ displayedText() }}<span class="animate-pulse text-cyber-cyan">_</span>
          </div>
          
          @if (isTypingDone()) {
            <div class="absolute bottom-4 right-6 text-cyber-yellow font-console text-sm animate-bounce mt-4">
              [ Clique ou Aperte Enter para avançar ]
            </div>
          }
        </div>
        
        <button 
          (click)="skipIntro($event)"
          tabindex="0"
          class="absolute top-8 right-8 text-white/50 hover:text-white font-console text-sm uppercase border border-white/20 hover:border-white/50 px-4 py-2 transition-all hover:bg-white/10 z-20 cursor-pointer">
          Pular Introdução >>
        </button>
      </div>
    </div>
  `
})
export class StoryIntroComponent implements OnInit, OnDestroy {
  router = inject(Router);

  slides: IntroSlide[] = [
    {
      id: 0,
      speaker: 'PROFESSOR MIRABERTO',
      imageType: 'miraberto',
      text: 'Saudações! Eu sou o Professor Miraberto, pós-doutor em Ciência da Computação. Eu desenvolvi as 32 "Cartas do Poder" das linguagens de programação. O portador dessas cartas recebe todas as habilidades necessárias para desenvolver códigos totalmente otimizados e limpos, tornando-se um dominador completo de todos os recursos da linguagem representada.'
    },
    {
      id: 1,
      speaker: 'ALERTA DE SEGURANÇA',
      imageType: 'ralapenha',
      text: 'Entretanto, sofremos uma brecha letal. O autoproclamado Hacker Ralapenha, um cibercriminoso do mal, roubou todas as cartas. Ele pretende usá-las para tentar dominar totalmente o mundo da computação, ganhando controle absoluto sobre qualquer código escrito no mundo.'
    },
    {
      id: 2,
      speaker: 'COMANDO CENTRAL',
      imageType: 'zero_n',
      text: 'Atenção, Zero N. É por isso que ativamos você. Sua missão principal é rastrear os fragmentos do sistema, enfrentar os desafios lógicos e recuperar todas as 32 cartas perdidas. É a única forma de impedir a destruição mundial que Ralapenha planejou.'
    },
    {
      id: 3,
      speaker: 'PROFESSOR MIRABERTO',
      imageType: 'miraberto_final',
      text: 'Não se preocupe, Zero N. Em sua jornada, você irá aprender todos os conceitos de programação, a partir da lógica básica até a sintaxe avançada de cada linguagem. Novos poderes serão concedidos a você a cada carta recuperada. Mantenha o foco, escreva um código limpo e salve nosso mundo digital. Comece sua jornada agora!'
    }
  ];

  currentSlideIndex = signal(0);
  displayedText = signal('');
  isTypingDone = signal(false);
  
  private typeInterval: ReturnType<typeof setInterval> | null = null;
  private currentFullText = '';
  private charIndex = 0;

  ngOnInit() {
    this.startTyping();
  }

  ngOnDestroy() {
    if (this.typeInterval !== null) {
      clearInterval(this.typeInterval);
    }
  }

  currentSlideData() {
    return this.slides[this.currentSlideIndex()];
  }

  startTyping() {
    if (this.typeInterval !== null) clearInterval(this.typeInterval);
    
    this.displayedText.set('');
    this.isTypingDone.set(false);
    this.charIndex = 0;
    this.currentFullText = this.currentSlideData().text;

    this.typeInterval = setInterval(() => {
      if (this.charIndex < this.currentFullText.length) {
        this.displayedText.set(this.currentFullText.substring(0, this.charIndex + 1));
        this.charIndex++;
      } else {
        this.isTypingDone.set(true);
        if (this.typeInterval !== null) clearInterval(this.typeInterval);
      }
    }, 30); // Velocidade do efeito typewriter
  }

  @HostListener('window:keydown', ['$event'])
  handleKeyDown(event: KeyboardEvent) {
    if (event.key === 'Enter' || event.key === ' ') {
      this.advance();
    }
  }

  advance() {
    if (!this.isTypingDone()) {
      // Mostrar todo texto imediatamente
      if (this.typeInterval !== null) clearInterval(this.typeInterval);
      this.displayedText.set(this.currentFullText);
      this.isTypingDone.set(true);
    } else {
      // Avançar para a próxima cena
      if (this.currentSlideIndex() < this.slides.length - 1) {
        this.currentSlideIndex.set(this.currentSlideIndex() + 1);
        this.startTyping();
      } else {
        this.finishIntro();
      }
    }
  }

  skipIntro(event: Event) {
    event.stopPropagation();
    this.finishIntro();
  }

  finishIntro() {
    this.router.navigate(['/story/map']);
  }
}
