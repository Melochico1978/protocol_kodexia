import { Component, inject, signal, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { LoadingService } from '../../../services/loading.service';

@Component({
  standalone: true,
  selector: 'app-level',
  imports: [FormsModule],
  template: `
    <div class="h-full w-full flex flex-col bg-cyber-dark overflow-hidden relative">
      <header class="h-[50px] shrink-0 border-b border-cyber-cyan flex justify-between items-center px-4 bg-black">
        <button (click)="router.navigate(['/story/map'])" class="text-cyber-cyan font-console uppercase hover:text-white text-xs">
          << Abandonar Missão
        </button>
        <div class="font-console text-cyber-yellow font-bold uppercase text-sm">
          SISTEMA CENTRAL — NODE {{ levelId }}
        </div>
      </header>

      <main class="flex-1 flex overflow-hidden">
        
        <!-- Left Panel: Instruction & Mentor -->
        <div class="w-1/3 min-w-[320px] max-w-[500px] border-r border-white/10 bg-cyber-card flex flex-col items-stretch overflow-y-auto">
          
          <div class="p-6 pb-2">
            <span class="text-[10px] px-1.5 py-0.5 bg-cyber-pink/20 text-cyber-pink border border-cyber-pink rounded-sm uppercase inline-block mb-2">
              OBJETIVO PRIMÁRIO
            </span>
            <h2 class="font-console text-2xl text-white mb-4">Declarar Variável</h2>
            <p class="font-sans text-sm text-white/80 leading-relaxed mb-6">
              Em Java, precisamos definir explicitamente o tipo dos dados. 
              Sua missão é criar uma variável do tipo <code>String</code> chamada <strong>nome</strong> 
              e atribuir o valor <strong>"Zero N"</strong> a ela. O código deve terminar com ;
            </p>

            <div class="bg-black border border-cyber-cyan/30 p-4 mb-4 font-console text-sm">
              <span class="text-cyber-dim">Linguagem Alvo:</span> <span class="text-cyber-cyan">Java</span><br>
              <span class="text-cyber-dim">Expectativa:</span> <span class="text-cyber-green text-xs">String nome = "Zero N";</span>
            </div>
          </div>

          <!-- Space filler -->
          <div class="flex-1"></div>

          <!-- Mentor Overlay Component (Lower section constraint) -->
          <footer class="h-[140px] shrink-0 bg-[#0a0a14] border-t-2 border-cyber-green flex flex-row items-center p-4 gap-4 mt-auto">
            <div class="w-[80px] h-[80px] bg-[#333] border-2 border-cyber-green shrink-0 relative flex items-center justify-center">
              <span class="material-icons text-cyber-green" style="font-size: 40px">smart_toy</span>
            </div>
            <div class="font-console leading-relaxed text-[#eee] text-[13px] overflow-y-auto max-h-full">
              <strong>MIRABERTO:</strong> "Preste atenção! Diferente do JavaScript ou Python, o Java do Ralapenha é fortemente tipado. Lembre-se do 'S' maiúsculo em String e não esqueça o ponto-e-vírgula!"
            </div>
          </footer>

        </div>

        <!-- Right Panel: IDE and Console -->
        <div class="flex-1 flex flex-col bg-[#0f0f15]">
          
          <div class="flex items-center justify-between px-4 py-2 border-b border-white/10 bg-[#151520]">
            <span class="font-console text-xs text-cyber-dim uppercase">editor_workspace.java</span>
            <button (click)="executeCode()" class="bg-cyber-green/10 text-cyber-green border border-cyber-green px-4 py-1 text-xs font-console uppercase hover:bg-cyber-green hover:text-black hover:shadow-[0_0_10px_rgba(57,255,20,0.4)] transition-all">
              ▶ COMPILAR E EXECUTAR
            </button>
          </div>

          <div class="flex-1 p-4 relative">
            <!-- Line Numbers (Simulated) -->
            <div class="absolute left-0 top-0 bottom-0 w-10 border-r border-white/5 bg-black/20 flex flex-col items-center pt-4 text-cyber-dim/50 font-console text-xs select-none pointer-events-none">
              <span>1</span><span>2</span><span>3</span><span>4</span><span>5</span>
            </div>

            <textarea 
              [(ngModel)]="userCode"
              class="w-full h-full bg-transparent text-white font-console text-sm outline-none resize-none pl-12"
              spellcheck="false"
              placeholder="// Escreva seu código Java aqui..."
            ></textarea>
          </div>

          <!-- Console Terminal -->
          <div class="h-[200px] border-t-2 border-cyber-cyan bg-black p-4 font-console text-xs overflow-y-auto flex flex-col gap-1">
            <span class="text-cyber-dim">> SISTEMA PRONTO PELA INSTRUÇÃO...</span>
            
            @if (executionState() === 'executing') {
               <span class="text-cyber-yellow animate-pulse">> ANALISANDO SINTAXE E ALOCANDO RECURSOS...</span>
            }

            @if (executionState() === 'success') {
               <span class="text-cyan-400">> COMPILAÇÃO BEM SUCEDIDA.</span>
               <span class="text-cyber-green shadow-[0_0_5px_rgba(57,255,20,0.5)]">> TESTE PASSOU! XP +50. ACESSO GARANTIDO.</span>
               <button (click)="router.navigate(['/story/map'])" class="mt-4 self-start bg-transparent border border-cyber-cyan text-cyber-cyan py-1 px-4 uppercase hover:bg-cyber-cyan hover:text-black">Prosseguir >></button>
            }

            @if (executionState() === 'error') {
               <span class="text-cyber-pink">> FATAL ERROR. COMPILATION FAILED.</span>
               <span class="text-white/60">Dica: Verifique se declarou a String corretamente com maiúscula e adicionou o ; no final.</span>
            }
          </div>

        </div>

      </main>
    </div>
  `
})
export class LevelComponent implements OnInit {
  router = inject(Router);
  route = inject(ActivatedRoute);
  loading = inject(LoadingService);

  levelId = '0';
  userCode = '';
  executionState = signal<'idle' | 'executing' | 'success' | 'error'>('idle');

  ngOnInit() {
    this.route.paramMap.subscribe(params => {
      this.levelId = params.get('id') || '0';
    });
  }

  async executeCode() {
    if (!this.userCode.trim()) return;

    this.executionState.set('executing');
    
    // Simulate compilation delay to judge0 backend
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const code = this.userCode.trim();
    // Super basic string matching for simple mock logic based on the objective
    if (code.includes('String nome') && code.includes('Zero N') && code.endsWith(';')) {
      this.executionState.set('success');
    } else {
      this.executionState.set('error');
    }
  }
}
