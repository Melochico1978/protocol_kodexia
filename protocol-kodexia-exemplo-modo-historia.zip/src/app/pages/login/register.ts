import { Component, inject, signal } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { FormsModule } from '@angular/forms';
import { LoadingService } from '../../services/loading.service';

@Component({
  standalone: true,
  selector: 'app-register',
  imports: [FormsModule],
  template: `
    <div class="h-screen w-full flex items-center justify-center p-6 relative overflow-hidden bg-cyber-dark">
      <div class="z-10 bg-cyber-card border-2 border-cyber-cyan p-8 w-full max-w-md shadow-[0_0_20px_rgba(0,243,255,0.2)] max-h-screen overflow-y-auto">
        <div class="text-center mb-8">
          <h1 class="font-console font-black text-2xl text-cyber-cyan tracking-widest uppercase">Novo Registro</h1>
          <p class="font-sans text-sm text-cyber-dim mt-2 uppercase">Protocolo de Inserção</p>
        </div>

        <form (ngSubmit)="onSubmit()" class="flex flex-col gap-6">
          <div class="flex flex-col gap-2">
            <label for="fullName" class="font-console text-cyber-cyan text-sm uppercase">> Nome Completo_</label>
            <input 
              id="fullName"
              type="text" 
              name="fullName"
              [(ngModel)]="fullName"
              required
              class="bg-black border border-cyber-cyan/50 text-white font-console p-3 focus:outline-none focus:border-cyber-cyan focus:shadow-[0_0_10px_rgba(0,243,255,0.3)] transition-all"
              placeholder="Seu Nome Completo"
            >
          </div>

          <div class="flex flex-col gap-2">
            <label for="nickname" class="font-console text-cyber-cyan text-sm uppercase">> Codinome (Apelido)_</label>
            <input 
              id="nickname"
              type="text" 
              name="nickname"
              [(ngModel)]="nickname"
              required
              class="bg-black border border-cyber-cyan/50 text-white font-console p-3 focus:outline-none focus:border-cyber-cyan focus:shadow-[0_0_10px_rgba(0,243,255,0.3)] transition-all"
              placeholder="Zero N"
            >
          </div>

          <div class="flex flex-col gap-2">
            <label for="email" class="font-console text-cyber-cyan text-sm uppercase">> Email_</label>
            <input 
              id="email"
              type="email" 
              name="email"
              [(ngModel)]="email"
              required
              class="bg-black border border-cyber-cyan/50 text-white font-console p-3 focus:outline-none focus:border-cyber-cyan focus:shadow-[0_0_10px_rgba(0,243,255,0.3)] transition-all"
              placeholder="novo.agente@kodexia.gov"
            >
          </div>

          <div class="flex flex-col gap-2">
            <label for="password" class="font-console text-cyber-cyan text-sm uppercase">> Senha_</label>
            <input 
              id="password"
              type="password" 
              name="password"
              [(ngModel)]="password"
              required
              class="bg-black border border-cyber-cyan/50 text-white font-console p-3 focus:outline-none focus:border-cyber-cyan focus:shadow-[0_0_10px_rgba(0,243,255,0.3)] transition-all"
              placeholder="••••••••"
            >
          </div>
          
          @if (errorMsg()) {
            <div class="text-cyber-pink font-console text-sm animate-pulse border border-cyber-pink bg-cyber-pink/10 p-2">
              [!] Erro: {{ errorMsg() }}
            </div>
          }

          <button 
            type="submit" 
            class="mt-4 bg-transparent border-2 border-cyber-green text-cyber-green py-3 px-6 font-console uppercase hover:bg-cyber-green hover:text-black hover:shadow-[0_0_20px_rgba(57,255,20,0.6)] transition-all font-bold">
            > CADASTRAR-SE
          </button>
          
          <button 
            type="button" 
            (click)="goToLogin()"
            class="bg-transparent border border-white/20 text-white/60 py-2 px-6 font-console text-sm uppercase hover:border-white/50 hover:text-white transition-all">
            < Voltar para o Login
          </button>
        </form>
      </div>
    </div>
  `
})
export class RegisterComponent {
  private auth = inject(AuthService);
  private router = inject(Router);
  private loading = inject(LoadingService);

  fullName = '';
  nickname = '';
  email = '';
  password = '';
  errorMsg = signal('');

  async onSubmit() {
    if (!this.fullName || !this.nickname || !this.email || !this.password) {
      this.errorMsg.set('Dados Incompletos.');
      return;
    }

    this.loading.show();
    this.errorMsg.set('');

    try {
      await new Promise(resolve => setTimeout(resolve, 800));
      
      const success = await this.auth.register(this.fullName, this.nickname, this.email, this.password);
      if (success) {
         this.router.navigate(['/home']);
      } else {
         this.errorMsg.set('Este email já está em uso.');
      }
    } catch {
      this.errorMsg.set('Falha na conexão.');
    } finally {
      this.loading.hide();
    }
  }

  goToLogin() {
    this.router.navigate(['/login']);
  }
}
