import { Component, inject, signal, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { FormsModule } from '@angular/forms';
import { LoadingService } from '../../services/loading.service';

export interface GoogleProfile {
  name: string;
  email: string;
  picture: string;
}

@Component({
  standalone: true,
  selector: 'app-login',
  imports: [FormsModule],
  template: `
    <div class="h-screen w-full flex items-center justify-center p-6 relative overflow-hidden bg-cyber-dark">
      <div class="z-10 bg-cyber-card border-2 border-cyber-cyan p-8 w-full max-w-md shadow-[0_0_20px_rgba(0,243,255,0.2)]">
        
        @if (registrationMode() === 'standard') {
          <div class="text-center mb-8">
            <h1 class="font-console font-black text-2xl text-cyber-cyan tracking-widest uppercase">Acesso Restrito</h1>
            <p class="font-sans text-sm text-cyber-dim mt-2 uppercase">Protocolo de Identificação</p>
          </div>

          <form (ngSubmit)="onSubmit()" class="flex flex-col gap-6">
            <div class="flex flex-col gap-2">
              <label for="email" class="font-console text-cyber-cyan text-sm uppercase">> Email_</label>
              <input 
                id="email"
                type="email" 
                name="email"
                [(ngModel)]="email"
                required
                class="bg-black border border-cyber-cyan/50 text-white font-console p-3 focus:outline-none focus:border-cyber-cyan focus:shadow-[0_0_10px_rgba(0,243,255,0.3)] transition-all"
                placeholder="agente@kodexia.gov"
              >
            </div>

            <div class="flex flex-col gap-2">
              <label for="password" class="font-console text-cyber-cyan text-sm uppercase">> Senha_</label>
              <input 
                id="password"
                type="password" 
                name="password"
                [(ngModel)]="password"
                required
                class="bg-black border border-cyber-cyan/50 text-white font-console p-3 focus:outline-none focus:border-cyber-cyan focus:shadow-[0_0_10px_rgba(0,243,255,0.3)] transition-all"
                placeholder="••••••••"
              >
            </div>
            
            @if (errorMsg()) {
              <div class="text-cyber-pink font-console text-sm animate-pulse border border-cyber-pink bg-cyber-pink/10 p-2">
                [!] Erro: {{ errorMsg() }}
              </div>
            }

            <button 
              type="submit" 
              class="mt-4 bg-transparent border-2 border-cyber-cyan text-cyber-cyan py-3 px-6 font-console uppercase hover:bg-cyber-cyan hover:text-black hover:shadow-[0_0_20px_rgba(0,243,255,0.6)] transition-all font-bold">
              > AUTENTICAR
            </button>
            
            <button 
              type="button" 
              (click)="loginWithGoogle()"
              class="bg-transparent border border-white/20 text-white/60 py-2 px-6 font-console text-sm uppercase hover:border-white/50 hover:text-white transition-all">
              Login via Google OAuth
            </button>

            <button 
              type="button" 
              (click)="goToRegister()"
              class="bg-transparent border border-white/20 text-white/60 py-2 px-6 font-console text-sm uppercase hover:border-white/50 hover:text-white transition-all">
              Novo Agente? Cadastre-se
            </button>
          </form>
        }

        @if (registrationMode() === 'google_complete') {
          <div class="text-center mb-8">
            <h1 class="font-console font-black text-xl text-cyber-green tracking-widest uppercase">Perfil Google</h1>
            <p class="font-sans text-sm text-cyber-dim mt-2 uppercase">Complete seu Registro</p>
          </div>

          <form (ngSubmit)="onCompleteGoogleAuth()" class="flex flex-col gap-6">
            <div class="flex flex-col gap-2">
              <label for="googleName" class="font-console text-cyber-dim text-sm uppercase">> Nome (Identificado)_</label>
              <input 
                id="googleName"
                type="text" 
                [value]="googleProfile()?.name"
                disabled
                class="bg-black/50 border border-cyber-dim/30 text-cyber-dim font-console p-3 cursor-not-allowed"
              >
            </div>

            <div class="flex flex-col gap-2">
              <label for="googleNickname" class="font-console text-cyber-green text-sm uppercase">> Selecione um Codinome_</label>
              <input 
                id="googleNickname"
                type="text" 
                name="googleNickname"
                [(ngModel)]="nickname"
                required
                class="bg-black border border-cyber-green/50 text-white font-console p-3 focus:outline-none focus:border-cyber-green focus:shadow-[0_0_10px_rgba(57,255,20,0.3)] transition-all"
                placeholder="Zero N"
              >
            </div>

            @if (errorMsg()) {
              <div class="text-cyber-pink font-console text-sm animate-pulse border border-cyber-pink bg-cyber-pink/10 p-2">
                [!] Erro: {{ errorMsg() }}
              </div>
            }

            <button 
              type="submit" 
              class="mt-4 bg-transparent border-2 border-cyber-green text-cyber-green py-3 px-6 font-console uppercase hover:bg-cyber-green hover:text-black hover:shadow-[0_0_20px_rgba(57,255,20,0.6)] transition-all font-bold">
              > FINALIZAR CADASTRO
            </button>
            <button 
              type="button" 
              (click)="cancelGoogleAuth()"
              class="bg-transparent text-cyber-pink/80 py-1 px-4 font-console text-xs uppercase hover:text-cyber-pink transition-all">
              < Cancelar
            </button>
          </form>
        }

      </div>
    </div>
  `
})
export class LoginComponent implements OnInit, OnDestroy {
  private auth = inject(AuthService);
  private router = inject(Router);
  private loading = inject(LoadingService);

  email = '';
  password = '';
  nickname = '';
  errorMsg = signal('');
  registrationMode = signal<'standard' | 'google_complete'>('standard');
  googleProfile = signal<GoogleProfile | null>(null);

  private messageListener: (event: MessageEvent) => Promise<void> = async () => {};

  ngOnInit() {
    this.messageListener = async (event: MessageEvent) => {
      const origin = event.origin;
      if (!origin.endsWith('.run.app') && !origin.includes('localhost') && !origin.includes('0.0.0.0')) {
        return;
      }
      if (event.data?.type === 'OAUTH_AUTH_SUCCESS') {
        const payload = event.data.payload;
        this.handleGoogleSuccess(payload);
      }
    };
    window.addEventListener('message', this.messageListener as unknown as EventListener);
  }

  ngOnDestroy() {
    if (this.messageListener) {
      window.removeEventListener('message', this.messageListener as unknown as EventListener);
    }
  }

  async loginWithGoogle() {
    try {
      this.errorMsg.set('');
      const response = await fetch('/api/auth/google/url');
      if (!response.ok) {
        throw new Error('Failed to get auth URL');
      }
      const data = await response.json();

      const authWindow = window.open(
        data.url,
        'oauth_popup',
        'width=600,height=700'
      );

      if (!authWindow) {
        this.errorMsg.set('Popup bloqueado pelo navegador.');
      }
    } catch (error) {
      console.error('OAuth URL error:', error);
      this.errorMsg.set('Erro ao iniciar Google OAuth.');
    }
  }

  async handleGoogleSuccess(profile: GoogleProfile) {
    this.loading.show();
    try {
      const exists = await this.auth.checkUserExists(profile.email);
      if (exists) {
        await this.auth.loginGoogle(profile.email, profile.picture);
        this.router.navigate(['/home']);
      } else {
        this.googleProfile.set(profile);
        this.registrationMode.set('google_complete');
      }
    } catch {
      this.errorMsg.set('Falha na autenticação via Google.');
    } finally {
      this.loading.hide();
    }
  }

  async onCompleteGoogleAuth() {
    if (!this.nickname) {
      this.errorMsg.set('Insira um codinome.');
      return;
    }
    const profile = this.googleProfile();
    if (!profile) return;

    this.loading.show();
    try {
      await this.auth.registerGoogle(profile.name, this.nickname, profile.email, profile.picture);
      this.router.navigate(['/home']);
    } catch {
      this.errorMsg.set('Erro ao completar registro.');
    } finally {
      this.loading.hide();
    }
  }

  cancelGoogleAuth() {
    this.registrationMode.set('standard');
    this.googleProfile.set(null);
    this.nickname = '';
    this.errorMsg.set('');
  }

  async onSubmit() {
    if (!this.email || !this.password) {
      this.errorMsg.set('Credenciais Incompletas.');
      return;
    }

    this.loading.show();
    this.errorMsg.set('');

    try {
      await new Promise(resolve => setTimeout(resolve, 800));
      
      const success = await this.auth.login(this.email, this.password);
      if (success) {
         this.router.navigate(['/home']);
      } else {
         this.errorMsg.set('Credenciais Invalidas ou Usuário não encontrado.');
      }
    } catch {
      this.errorMsg.set('Falha na conexão.');
    } finally {
      this.loading.hide();
    }
  }

  goToRegister() {
    this.router.navigate(['/register']);
  }
}
