import {Component, inject, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {AuthService} from '../../services/auth.service';

@Component({
  standalone: true,
  selector: 'app-home',
  template: `
    <div class="h-full w-full flex flex-col">
      <header class="h-[60px] shrink-0 border-b-2 border-cyber-cyan flex justify-between items-center px-6 bg-[rgba(0,243,255,0.05)] shadow-[0_0_15px_rgba(0,243,255,0.2)]">
        <div>
          <h1 class="font-console font-black text-xl tracking-[2px] text-cyber-cyan uppercase">Terminal Central</h1>
          <p class="font-sans text-xs mt-1 text-cyber-cyan opacity-80 uppercase">Bem-vindo, {{ user()?.name || 'Zero N' }}.</p>
        </div>
        
        <div class="flex items-center gap-6 font-console text-sm">
          <div class="flex gap-6">
            <div class="flex flex-col items-end">
              <span class="text-cyber-dim">LVL</span>
              <span class="text-cyber-green font-bold">{{ user()?.level || 1 }}</span>
            </div>
            <div class="flex flex-col items-end">
              <span class="text-cyber-dim">EXP</span>
              <span class="text-cyber-green font-bold">{{ user()?.xp || 0 }} / 1000</span>
            </div>
          </div>
          <button (click)="logout()" class="ml-4 border border-cyber-pink text-cyber-pink font-console px-3 py-1 uppercase text-xs hover:bg-cyber-pink hover:text-black transition-colors">
            Desconectar
          </button>
        </div>
      </header>

      <main class="flex-1 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 p-6 relative overflow-y-auto">
        
        <!-- Story Mode Card -->
        <div tabindex="0" (keyup.enter)="router.navigate(['/story/intro'])" (click)="router.navigate(['/story/intro'])" class="bg-cyber-card border border-white/10 rounded overflow-hidden flex flex-col gap-3 p-4 relative shadow-[inset_0_0_20px_rgba(0,0,0,0.5)] hover:border-cyber-cyan hover:shadow-[0_0_15px_rgba(0,243,255,0.3)] transition-all cursor-pointer group">
          <span class="text-[10px] px-1.5 py-0.5 bg-white/10 rounded-sm uppercase inline-block self-start text-white">HISTORIA</span>
          <div class="aspect-video bg-[#2a2a3a] border-4 border-black relative overflow-hidden flex items-center justify-center">
            <div class="w-16 h-16 bg-cyber-cyan rounded border-4 border-white"></div>
          </div>
          <h2 class="font-console text-[20px] text-cyber-cyan text-center mt-2 group-hover:text-white transition-colors">Modo Historia</h2>
          <p class="font-sans text-sm text-white/80 text-center mb-4">Recupere as Cartas de Poder roubadas por Ralapenha.</p>
          <button class="mt-auto bg-transparent border border-cyber-cyan text-cyber-cyan py-3 px-6 font-console uppercase transition-all group-hover:bg-cyber-cyan group-hover:text-black group-hover:shadow-[0_0_20px_var(--color-cyber-cyan)]">
            > ACESSAR_
          </button>
        </div>

        <!-- Battle Mode Card -->
        <div class="bg-cyber-card border border-white/10 rounded overflow-hidden flex flex-col gap-3 p-4 relative shadow-[inset_0_0_20px_rgba(0,0,0,0.5)] hover:border-cyber-pink hover:shadow-[0_0_15px_rgba(255,0,255,0.3)] transition-all cursor-pointer group">
          <span class="text-[10px] px-1.5 py-0.5 bg-white/10 rounded-sm uppercase inline-block self-start text-white">COMPETITIVO</span>
          <div class="aspect-video bg-[#2a2a3a] border-4 border-black relative overflow-hidden flex items-center justify-center">
            <div class="w-16 h-16 bg-cyber-pink rounded border-4 border-white"></div>
          </div>
          <h2 class="font-console text-[20px] text-cyber-pink text-center mt-2 group-hover:text-white transition-colors">Batalha (TCG)</h2>
          <p class="font-sans text-sm text-white/80 text-center mb-4">Enfrente bots num duelo de atributos de código.</p>
          <button class="mt-auto bg-transparent border border-cyber-pink text-cyber-pink py-3 px-6 font-console uppercase transition-all group-hover:bg-cyber-pink group-hover:text-black group-hover:shadow-[0_0_20px_var(--color-cyber-pink)]">
            > EM BREVE_
          </button>
        </div>
      </main>

    </div>
  `
})
export class HomeComponent implements OnInit {
  auth = inject(AuthService);
  router = inject(Router);
  user = this.auth.currentUser;

  ngOnInit() {
    this.auth.initAuth();
  }

  logout() {
    this.auth.logout();
  }
}
