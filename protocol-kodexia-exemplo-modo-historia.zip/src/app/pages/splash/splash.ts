import {Component, inject, OnInit} from '@angular/core';
import {Router} from '@angular/router';

@Component({
  standalone: true,
  selector: 'app-splash',
  template: `
    <div class="h-screen w-full flex flex-col items-center justify-center bg-cyber-dark text-cyber-cyan p-4 relative overflow-hidden">
      <div class="animate-pulse flex flex-col items-center gap-6 z-10">
        <h1 class="font-console font-black tracking-[4px] text-4xl text-cyber-pink drop-shadow-[0_0_10px_var(--color-cyber-pink)] text-center">
          KODEXIA :: PROTOCOL
        </h1>
        <div class="h-2 w-64 border border-cyber-cyan p-0.5">
          <div class="h-full bg-cyber-cyan shadow-[0_0_8px_var(--color-cyber-cyan)]" [style.width.%]="progress"></div>
        </div>
        <p class="font-console text-xl animate-bounce">Carregando Sistemas...</p>
      </div>
      
      <!-- Footer Copyright/Studio branding -->
      <div class="absolute bottom-4 font-console text-sm text-cyber-cyan/60 z-10">
        (C) 2026 PROF. MIRABERTO SYSTEMS INC.
      </div>
    </div>
  `
})
export class SplashComponent implements OnInit {
  private readonly router = inject(Router);
  progress = 0;

  ngOnInit() {
    this.simulateLoading();
  }

  private simulateLoading() {
    const interval = setInterval(() => {
      this.progress += Math.floor(Math.random() * 15) + 5;
      
      if (this.progress >= 100) {
        this.progress = 100;
        clearInterval(interval);
        setTimeout(() => {
          this.router.navigate(['/home']);
        }, 500);
      }
    }, 300);
  }
}
